// import {async, ComponentFixture, TestBed} from '@angular/core/testing';

// import {McompareModalComponent} from './mcompare-modal.component';

// describe('CdataModalComponent', () => {
//   let component: McompareModalComponent;
//   let fixture: ComponentFixture<McompareModalComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [McompareModalComponent]
//     }).compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(McompareModalComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

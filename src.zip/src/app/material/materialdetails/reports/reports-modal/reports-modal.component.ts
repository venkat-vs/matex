import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-reports-modal',
  templateUrl: './reports-modal.component.html',
  styleUrls: ['./reports-modal.component.css']
})
export class ReportsModalComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}

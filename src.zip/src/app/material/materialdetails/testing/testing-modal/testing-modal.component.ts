import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-testing-modal',
  templateUrl: './testing-modal.component.html',
  styleUrls: ['./testing-modal.component.css']
})
export class TestingModalComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}

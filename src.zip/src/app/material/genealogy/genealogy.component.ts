import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-genealogy',
  templateUrl: './genealogy.component.html',
  styleUrls: ['./genealogy.component.css']
})
export class GenealogyComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
